package com.ti2.horario

import android.R
import android.os.Bundle
import android.os.Handler
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.miguelcatalan.materialsearchview.MaterialSearchView
import com.miguelcatalan.materialsearchview.MaterialSearchView.SearchViewListener
import okhttp3.OkHttpClient


class AsignarDocente : AppCompatActivity() {
    val client = OkHttpClient()
    var handler: Handler = Handler()

    var searchView: MaterialSearchView? = null
    var toolbar: Toolbar? = null

    private val PROFES = arrayOf("asdasd","asdsad","ASDASdasd")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.asignar_docente)
        toolbar =  findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar);
        init()
    }

    fun init()
    {
        val searchView = findViewById<MaterialSearchView>(R.id.search_view)
        searchView.setSuggestions(getResources().getStringArray(R.array.query_suggestions))
        searchView.setEllipsize(true)
        searchView.setOnQueryTextListener(object : MaterialSearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                Toast.makeText(applicationContext, query, Toast.LENGTH_SHORT).show()
                return false
            }

            override fun onQueryTextChange(newText: String): Boolean {
                return false
            }
        })

        searchView.setOnSearchViewListener(object : SearchViewListener {
            override fun onSearchViewShown() {}
            override fun onSearchViewClosed() {}
        })
        /*val request = Request.Builder()
            .url(url)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {}
            override fun onResponse(call: Call, response: Response) {

                val txt_response = findViewById<SearchView>(R.id.simpleSearchView)
                //txt_response.setText( response.message )
                val message = response.body!!.string()
                Log.e("TAGGGGGGGGGGGGGG", response.message)

                //handler.post { txt_response.}
            }
        })
        */
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_dash, menu)
        val item: MenuItem = menu.findItem(R.id.action_search)
        searchView!!.setMenuItem(item)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.getItemId()) {
            R.id.action_search -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        if (searchView!!.isSearchOpen) {
            searchView!!.closeSearch()
        } else {
            super.onBackPressed()
        }
    }


}
