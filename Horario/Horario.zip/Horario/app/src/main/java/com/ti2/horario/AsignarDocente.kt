package com.ti2.horario

import android.app.SearchManager
import android.database.MatrixCursor
import android.os.Bundle
import android.os.Handler
import android.provider.BaseColumns
import android.widget.Toolbar
import androidx.appcompat.app.AppCompatActivity
import com.miguelcatalan.materialsearchview.MaterialSearchView
import okhttp3.OkHttpClient


class AsignarDocente : AppCompatActivity() {
    val client = OkHttpClient()
    var handler: Handler = Handler()

    var searchView: MaterialSearchView? = null
    var toolbar: Toolbar? = null

    private val PROFES = arrayOf("asdasd","asdsad","ASDASdasd")
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.asignar_docente)
        toolbar =  findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar);
        searchViewCode()
        init("192.168.0.9/")
    }

    fun init(url: String)
    {
        val materialSearchView = findViewById<MaterialSearchView>(R.id.mysearch)
        val suggestions = listOf("Apple", "Blueberry", "Carrot", "Daikon")

        materialSearchView.setOnQueryTextListener(object  : MaterialSearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(query: String?): Boolean {
                val cursor = MatrixCursor(arrayOf(BaseColumns._ID, SearchManager.SUGGEST_COLUMN_TEXT_1))
                query?.let {
                    suggestions.forEachIndexed { index, suggestion ->
                        if (suggestion.contains(query, true))
                            cursor.addRow(arrayOf(index, suggestion))
                    }
                }

                cursorAdapter.changeCursor(cursor)
                return true
            }
        })


        /*val request = Request.Builder()
            .url(url)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {}
            override fun onResponse(call: Call, response: Response) {

                val txt_response = findViewById<SearchView>(R.id.simpleSearchView)
                //txt_response.setText( response.message )
                val message = response.body!!.string()
                Log.e("TAGGGGGGGGGGGGGG", response.message)

                //handler.post { txt_response.}
            }
        })
        */
    }


}
